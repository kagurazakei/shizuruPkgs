# cyberpunk-technotronic-icon-theme

${{\color{greenyellow}\Huge{\textsf{NOTICE:}}}}\$ <code>I will continue to develop the theme but I won't do it on github, just locally on my machine. You will find weekly or semi-weekly updates on pling and your DE app store.</code>

 <code>Why am I doing this?</code>

 <code>I created this account on github in the hope of attracting collaborators. Nevertheless, more than a year has passed and no one has expressed interest. Since there are no collaborators, it's of little use to me to continue to maintain the theme on github. From now on, I'm creating new icons, put them in the icon theme and upload it on pling.</code>

 <code>You are welcome to open issues, pull requests and contact me both on github and pling.</code>

${{\color{greenyellow}\{\textsf{I am creating new themes (same icons) in different gradients (cyberpunk style). You'll find them on pling.}}}}\$

<br/>

a blue-purple (oomox) gradient full-icon theme.

For all of us that love cyberpunk, neon, outrun, synthwave and retrofuture aesthetics.

**Feel free to ask for new icons**

Package releases on [pling](https://www.pling.com/p/1999292)

Donation info [here](https://dreifacherspass.github.io/) 

The Ultimate-Punk-Suru++ icon theme was awesome. But it hasn't received updates for years and it also uses the same generic icons for a multitude of applications.

I am creating an icon pack based on the Ultimate-Punk-Suru++, removing the generic icons and adding new ones specific for each application, mimetype, action etc. I am colouring all icons using our beloved blue-purple gradient, so that the icon pack has a uniform look.

* CC BY-SA 2.0 © [Ultimate-Punk-Suru++](https://www.opendesktop.org/p/1333537/) by [rtl88](https://www.opendesktop.org/u/rtl88)
